# Promo Radar NG

Everything for Promo Radar NG in one place:

- `docs/` — the website people use (`index.html`). GitHub Pages hosts it for free.
- `promo_radar/` — the deal finder. It visits Nigerian shops, keeps only real discounts, and writes `docs/deals.json`, which the website reads.
- `.github/workflows/find-deals.yml` — runs the deal finder every 4 hours on GitHub for free.

Until the first run finishes, the website shows example deals with a note saying so.

## Put it live on GitHub (about 20 minutes, no coding)

### 1. Create the repository
1. Sign up or log in at github.com.
2. Click **+** (top right) → **New repository**.
3. Name it `promo-radar-ng`. Choose **Public** (public repositories get unlimited free run time). Click **Create repository**.

### 2. Upload the files
1. On the new repository page, click **uploading an existing file**.
2. Unzip this project on your computer, open the `promo-radar-ng` folder, select everything inside it, and drag it into the upload box.
   - The `.github` folder is hidden on some computers. If it doesn't upload, create it by hand: click **Add file → Create new file**, type `.github/workflows/find-deals.yml` as the name, and paste in the contents of that file.
3. Click **Commit changes**.

### 3. Turn on the website
1. Go to **Settings → Pages**.
2. Under **Build and deployment**, set Source to **Deploy from a branch**, Branch to **main**, folder to **/docs**. Click **Save**.
3. After a minute or two, the page shows your site address, e.g. `https://yourname.github.io/promo-radar-ng/`.

### 4. Let the deal finder save its results
1. Go to **Settings → Actions → General**.
2. Under **Workflow permissions**, choose **Read and write permissions**. Click **Save**.

### 5. Run it the first time
1. Open the **Actions** tab. If asked, click to enable workflows.
2. Click **Find deals** → **Run workflow**.
3. When it shows a green tick (a few minutes), refresh your website. Live deals replace the examples.
4. After that it runs by itself every 4 hours.

### 6. Add your affiliate IDs (after approval)
1. Go to **Settings → Secrets and variables → Actions → New repository secret**.
2. Add `JUMIA_AFFILIATE_ID`, `KONGA_AFFILIATE_ID`, `SLOT_AFFILIATE_ID`, `KARA_AFFILIATE_ID` as you get them.
3. Open `promo_radar/affiliate.py` and make sure each link format matches exactly what the affiliate dashboard gives you. The formats there now are placeholders.

### 7. Use your own domain (optional)
1. Buy `promoradar.com.ng` (or similar) from a Nigerian domain registrar.
2. In **Settings → Pages → Custom domain**, enter it and follow GitHub's instructions for the DNS records.

## If something goes wrong

- **A shop shows 0 deals:** the shop changed its page design. Open the deal page in a browser, inspect a product card, and update the selectors in `promo_radar/scrapers/`.
- **The run has a red X:** click it to see the error. Most often it's step 4 (permissions) not done.
- **Website still shows examples:** check the run finished with a green tick and that `docs/deals.json` exists in the repository.

## What the deal finder checks

Each deal is hidden if it is:
- less than 10% off, or 90% or more off (almost always an error)
- an old price raised in the last 30 days to fake a bigger discount
- from TikTok Shop, Temu, Alibaba, AliExpress or Shein

It also obeys each shop's robots.txt, waits 4 seconds between pages, and removes deals not seen for 24 hours.

## Add a new shop

- Shops built on Magento (product cards with `product-item`): add an entry to `STORES` in `promo_radar/config.py` with `"scraper": "magento"` and its deal page URLs. No new code needed.
- Other shops need a small scraper file in `promo_radar/scrapers/`. Copy `jumia.py` and change the selectors.
- Konga loads products with JavaScript, so a plain page download sees nothing. Use Konga's affiliate product feed once approved.

## Run it on your own computer (optional)

```
pip install -r requirements.txt
python run.py                 # all shops
python run.py --store jumia   # one shop
python -m pytest              # run the checks
```
