import json
import os

import pytest

from promo_radar import config, db, pipeline
from promo_radar.models import Deal
from promo_radar.scrapers.base import parse_naira
from promo_radar.scrapers.jumia import JumiaScraper
from promo_radar.scrapers.magento import MagentoScraper

HERE = os.path.dirname(__file__)


def fixture(name):
    with open(os.path.join(HERE, "fixtures", name), encoding="utf-8") as f:
        return f.read()


class FakeFetcher:
    """Serves saved pages instead of hitting the shops."""
    def __init__(self, pages):
        self.pages = pages

    def get(self, url):
        for key, html in self.pages.items():
            if key in url and "page=" not in url and "p=" not in url.split("?")[-1]:
                return html
        return None


def test_parse_naira():
    assert parse_naira("₦ 189,000") == 189000
    assert parse_naira("₦249,000.00") == 249000
    assert parse_naira("₦ 5,000 - ₦ 7,000") == 5000
    assert parse_naira("") == 0


def test_jumia_parser():
    s = JumiaScraper("jumia", config.STORES["jumia"])
    deals = list(s.parse(fixture("jumia.html"), "https://www.jumia.com.ng/x/", None))
    assert len(deals) == 3  # spaghetti has no old price, so it is skipped
    spark = deals[0]
    assert spark.price == 189000 and spark.old_price == 229000
    assert spark.url == "https://www.jumia.com.ng/tecno-spark-30-8gb-256gb-123456.html"
    assert spark.discount_percent == 17


def test_magento_parser():
    s = MagentoScraper("slot", config.STORES["slot"])
    deals = list(s.parse(fixture("magento.html"), "https://slot.ng/mobile-phones.html", "Phones"))
    assert [d.price for d in deals] == [249000, 689000]
    assert deals[0].image.endswith("a16.jpg")


def test_full_run(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "STORES", {
        "jumia": {"name": "Jumia", "scraper": "jumia", "pages": [("https://www.jumia.com.ng/flash-sales/", None)]},
        "slot": {"name": "Slot", "scraper": "magento", "base_url": "https://slot.ng",
                 "pages": [("https://slot.ng/mobile-phones.html", "Phones")]},
    })
    monkeypatch.setitem(config.AFFILIATE, "jumia", "TEST123")
    fetcher = FakeFetcher({"jumia.com.ng": fixture("jumia.html"), "slot.ng": fixture("magento.html")})
    out_path = tmp_path / "deals.json"
    stats = pipeline.run(db_path=str(tmp_path / "d.db"), export_path=str(out_path), fetcher=fetcher)

    # USB cable is only 5% off -> hidden. 4 real deals listed.
    assert stats["shown"] == 4 and stats["hidden"] == 1
    data = json.loads(out_path.read_text())
    titles = {d["title"]: d for d in data["deals"]}
    assert titles["Oraimo FreePods 4 ANC Earbuds"]["category"] == "Electronics"
    assert titles["Tecno Spark 30 6.78\" 8GB RAM/256GB ROM"]["link"].startswith("https://kol.jumia.com/")
    assert titles["Samsung Galaxy A16 128GB"]["link"] == "https://slot.ng/samsung-galaxy-a16-128gb.html"


def test_fake_discount_is_hidden(tmp_path):
    conn = db.connect(str(tmp_path / "d.db"))
    honest = Deal("kara", "Hisense 43in TV", "https://www.kara.com.ng/tv.html", 335000, 420000, "Electronics")
    pipeline.process([honest], conn)
    # A week later the shop "raises" the old price to make the discount look bigger.
    trick = Deal("kara", "Hisense 43in TV", "https://www.kara.com.ng/tv.html", 335000, 520000, "Electronics")
    assert pipeline.check(trick, conn) == "old price inflated"


def test_blocked_marketplace(tmp_path):
    conn = db.connect(str(tmp_path / "d.db"))
    d = Deal("x", "Dress", "https://www.shein.com/dress.html", 5000, 20000)
    assert pipeline.check(d, conn) == "blocked marketplace"
